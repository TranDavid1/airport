public class EmptyQueueException extends RuntimeException
{
    public EmptyQueueException()
    {
        super();
    } //end EmptyQueueException
} //end EmptyQueueException
